package com.telusko;

public class Alien {

	public Alien() {
		System.out.println("Object Created");
	}
	
	public void code() {
		System.out.println("Coding");
	}
	
}
