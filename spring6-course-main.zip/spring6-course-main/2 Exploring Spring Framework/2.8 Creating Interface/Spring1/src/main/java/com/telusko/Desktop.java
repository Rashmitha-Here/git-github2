package com.telusko;

public class Desktop implements Computer {


	public void compile() {
		System.out.println("Compiling using Desktop");
	}
}
