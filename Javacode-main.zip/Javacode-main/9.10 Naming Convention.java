public class Demo
{
	public static void main(String a[]) 
	{
	}
}


// Camel casing

// class and interface - Calc       ( first letter capital)
//variable and method - marks, show()    (small letters)
// constants - PIE, BRAND       (all capital letters)


//showMyMarks()     (first letter of each word is capital from second word)
//show_my_marks()   (words join by underscore)

// MyData

// age, DATA, Human()