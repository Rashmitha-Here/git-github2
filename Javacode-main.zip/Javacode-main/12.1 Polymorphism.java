Polymorphism:
- Many behaviour ( same object or reference has differnet behaviours)

1. Compile time polymorhism -- Overloading
	add(int, int)
	add(int, int, int)

2. Run time polymorphism -- Overriding
	A
		add(int,int)
	B
		add(int, int)