Types of error:-
1. Complile - time error
2. Runtime error -> Exception handling
3. Logical error


public class Demo {
    public static void main(String[] args) {
    
//  	System.out.Println();
    	System.out.println(2+2);
    	
    }
}