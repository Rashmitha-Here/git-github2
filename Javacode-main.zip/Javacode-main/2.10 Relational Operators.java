public class hello {

	public static void main(String[] args) {
		int x=6;
		int y=5;
//		boolean result= x<y;
//		boolean result= x>y;
//		boolean result= x>=y;
//		boolean result= x<=y;
//		boolean result= x!=y;
		boolean result= x==y;
		System.out.println(result);
		
		double a=8.8;
		double b=9.8;
//		boolean res = a<=b;		
		boolean res = a>=b;
	
		System.out.println(res);
	}

}