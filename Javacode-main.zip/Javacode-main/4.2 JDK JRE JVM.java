JDK- Java Development Kit
JVM- Java Virtual Machine
JRE- Java Runtime Environment