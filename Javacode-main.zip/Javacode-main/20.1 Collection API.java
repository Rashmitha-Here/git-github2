Collection API -> concept
Collection -> Interface
Collections -> classe with multiple methods
			    different type of data structures

