int i=5;
int j=6;
int k=7;
int num[]= {5,6,7};
int num[]=new int[4];