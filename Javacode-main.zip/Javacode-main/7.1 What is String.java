public class Demo {
	public static void main(String[] args) 
	{
		String name=new String();
		System.out.println(name);
		System.out.println(name.hashCode());
		System.out.println("hello "+name);
		System.out.println(name.concat("reddy"));
//      String name="Navin";
		
	}
}