Inheritance:-

is, has
is is used in inheritance

Class Calc     //Parent class , Super, Base
{
	add()
	sub()
	multi()
	div()
}

Class AdvCalc     //Child class, Sub, Derived 
{
	{
	}
}	