class A{
	
}
class B extends A{
	
}
//class C extends A,B
// Multiple inheritance does not supported by Java
// Ambiguity issue
class C extends B{
	
}

public class Demo{
	public static void main(String args[])
	{
		
	}
}