:\Users\DELL>jshell
|  Welcome to JShell -- Version 17.0.3.1
|  For an introduction type: /help intro

jshell> System.out.println("Hello World")
Hello World

jshell> System.out.println("Navin Reddy, Telusko")
Navin Reddy, Telusko

jshell> 2+4
$3 ==> 6

jshell> 9-6
$4 ==> 3

jshell>