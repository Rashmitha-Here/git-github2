public class Demo {
	public static void main(String[] args) 
	{
		int nums[]=new int[4];
	}
}


Drawbacks:-
- The memory allocation is contiguous.
- The size of an array is fixed. Array size cannot be expand.
- Searching takes time.
- Array can store values of only same type. It can store homogeneous type value only.