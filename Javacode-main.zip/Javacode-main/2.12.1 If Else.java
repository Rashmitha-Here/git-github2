public class hello {

	public static void main(String[] args) {
//		int x=8;
//		System.out.println("Hello");
//		System.out.println("Bye");
		
//		int x=18;
//		if(x>10) {
//			System.out.println("Hello");
//		}
		
//		if(true) {
//			System.out.println("Hello");
//		}
		
//		int x=28;
//		if(x>10 && x<=20) {       //11-20
//			System.out.println("Hello");
//		}
//		System.out.println("Bye");
		
//		int x=28;
//		if(x>10 && x<=20) {       //11-20
//			System.out.println("Hello");
//		}
//		else
//		System.out.println("Bye");
		
		int x=8;
		int y=7;
		if(x>y) {
			System.out.println(x);
			System.out.println("Thankyou");
		}
		else
			System.out.println(y);		
	}

}
