For loop:-
If you know how many iterations you want to go for loop
(intiliazing vaue, condition, increment or decrement)

While loop:-
When you need to read the file go for while loop, if the number of iterations is not known.

- For loop can also be used as a while.
 
Do While Loop:-
If you condition get false but you want to exceute the code at least once.
