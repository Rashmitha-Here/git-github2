public class hello {

	public static void main(String[] args) {
		//repeat this statement 4 times
		//loop -while, do while, for
		
		//100 - condition
		
		System.out.println("Hi");
			
	}
}
