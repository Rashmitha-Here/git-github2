public class hello {

	public static void main(String[] args) {
		System.out.print(3+5);
		System.out.print(8+7);
		
		//int num1=3;
		//int num2=5;
		//System.out.println(num1+num2);
		
		int num1=3;
		int num2=5;
		int result=num1+num2;
		System.out.println(result);
	}
}