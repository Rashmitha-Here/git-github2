- New State   
- Runnable State  ->  start() method
- Running State     -> a thead is running with run() method 
- Waiting State	    -> sleep(),  wait() method
- Dead State

Through notify(), you will go to waiting state to runnable state.
From Running, Runnable state to dead state through stop() method.