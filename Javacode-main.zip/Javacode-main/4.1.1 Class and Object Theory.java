class Demo
{
	public static void main(String[] args) 
	{
		
	}
}

// Object Oriented programming
// Object - Properties and Beahaviors

//Class